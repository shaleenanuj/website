from LoggingFile import Logger


lg = Logger()
lg.log("hello world")
